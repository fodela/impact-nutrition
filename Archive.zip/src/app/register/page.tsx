import { RegisterForm } from "../../components/form";

export default function RegisterPage() {
  return (
    <div>
      <div className="m-4">
        <RegisterForm />
      </div>
    </div>
  );
}
