import React from 'react'

const Administrator = () => {
  return (
    <div>Administrator page should be logged in to see it</div>
  )
}

export default Administrator