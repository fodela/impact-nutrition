'use client'
import React, { lazy } from 'react'

const Loading = () => {
    return (
        <div className='text-center text-4xl'>loading.........</div>
    )
}

export default Loading