'use client'

import DashboardEvents from "@/components/Dashboard/DashboardEvent/DashboardEvents"

const page = () => {
    return (
        <DashboardEvents />
    )
}

export default page