'use client'
import DashboardPost from '@/components/Dashboard/DashboardPost/DashboardPost'
import React from 'react'

const page = () => {
    return (
        <DashboardPost />
    )
}

export default page