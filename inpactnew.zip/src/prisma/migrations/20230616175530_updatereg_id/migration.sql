-- DropIndex
DROP INDEX "Attendee_userId_key";
