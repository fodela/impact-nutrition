import React from 'react'

const DashboardCards = () => {
    return (
        <div className='bg-white rounded px-2 w-80'>
            sometest
        </div>
    )
}

export default DashboardCards