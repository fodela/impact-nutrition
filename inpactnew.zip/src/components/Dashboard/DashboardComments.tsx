import React from 'react'

const DashboardComments = () => {
    return (
        <div>DashboardComments</div>
    )
}

export default DashboardComments