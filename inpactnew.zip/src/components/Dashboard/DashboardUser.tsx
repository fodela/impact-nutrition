import React from 'react'

const DashboardUser = () => {
    return (
        <div>DashboardUser</div>
    )
}

export default DashboardUser