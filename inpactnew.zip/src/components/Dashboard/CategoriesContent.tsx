import React from 'react'

const CategoriesContent = () => {
    return (
        <div>CategoriesContent</div>
    )
}

export default CategoriesContent