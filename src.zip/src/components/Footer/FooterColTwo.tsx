"use client"
const FooterColTwo = () => {
  return (
    <div className="p-4 md:flex flex-col gap-6">
      <div className="font-bold">
        <p>Directorates</p>
        <p>Administrative Affairs</p>
        <p>Finance</p>
        <p>Projects</p>
        <p>Monitoring and Evaluation</p>
        <p>International Relations Affairs</p>
        <p>Information Technology</p>
      </div>
      <div className="font-bold">

      </div>
    </div>
  );
};

export default FooterColTwo;

