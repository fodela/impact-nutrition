import { RegisterForm } from "../../components/form";

export default function RegisterPage() {
  return (
    <div>
      <div className="m-4 py-6">
        <RegisterForm />
      </div>
    </div>
  );
}
